// Einfache Prüfung der Geschäftslogik. Ausführen mit: npm run check
import { addDays, atTime, startOfWeek } from '../src/domain/dateUtils'
import {
  busyMinutes,
  deadlineUrgency,
  eventsForDay,
  findFreeSlots,
  findOverlaps,
  isHeavyDay,
  nextEvent,
} from '../src/domain/schedule'
import { createTestEvents } from '../src/sources/testSource'
import { SOURCES, loadAllSources } from '../src/sources'
import type { EventSource } from '../src/sources/types'

let failed = 0
function check(name: string, ok: boolean, detail = '') {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' – ' + detail : ''}`)
  if (!ok) failed++
}

// Fester Zeitpunkt: Montag 12.10.2026, 20:17
const now = new Date(2026, 9, 12, 20, 17)
const events = createTestEvents(now)
const monday = startOfWeek(now)
const day = (n: number) => addDays(monday, n)

// 1. Überschneidung am Mittwoch
const wed = eventsForDay(events, day(2))
const overlaps = findOverlaps(wed.timed)
check('Mittwoch: 2 Vorlesungen überschneiden sich', overlaps.size === 2, `${overlaps.size} Termine`)

// 2. Montag und Dienstag ohne Überschneidung
check('Montag ohne Überschneidung', findOverlaps(eventsForDay(events, day(0)).timed).size === 0)

// 3. Stark belegter Tag am Donnerstag (10.5 h + 2.5 h)
const thuBusy = busyMinutes(eventsForDay(events, day(3)).timed, day(3))
check('Donnerstag ist stark belegt (>10 h)', isHeavyDay(thuBusy), `${thuBusy} min`)
const monBusy = busyMinutes(eventsForDay(events, day(0)).timed, day(0))
check('Montag ist nicht stark belegt', !isHeavyDay(monBusy), `${monBusy} min`)

// 4. Überschneidungen werden bei der Belegung nicht doppelt gezählt (Mittwoch 08:15–11:30 + 12:30–18:30 + 19:00–20:30)
const wedBusy = busyMinutes(wed.timed, day(2))
check('Mittwoch: Belegung ohne Doppelzählung', wedBusy === 195 + 360 + 90, `${wedBusy} min`)

// 5. Ganztägiger Termin am Freitag
const fri = eventsForDay(events, day(4))
check('Freitag: ganztägiger Termin erkannt', fri.allDay.length === 1)
const friSlots = findFreeSlots(fri, day(4), now)
check('Freitag: freie Zeit als unsicher markiert', friSlots.length > 0 && friSlots.every((s) => s.uncertain))

// 6. Kein Lernblock nach intensivem Training (Samstag Ausfahrt endet 12:00, hoch -> frühestens 13:00)
const sat = eventsForDay(events, day(5))
const satSlots = findFreeSlots(sat, day(5), now)
const afterRide = satSlots.find((s) => s.start.getHours() === 12)
check('Samstag: Lücke nach intensivem Training gefunden', !!afterRide)
check(
  'Samstag: Lernblock beginnt frühestens 1 h nach intensivem Training',
  !!afterRide?.study && afterRide.study.start >= atTime(day(5), 13, 0),
  afterRide?.study ? afterRide.study.start.toTimeString().slice(0, 5) : 'kein Lernblock',
)

// 7. Kein Lernblock nach 21:30 (Montag früh, damit nichts von "jetzt" abgeschnitten wird)
const earlyNow = new Date(2026, 9, 12, 5, 0)
const sun = eventsForDay(events, day(6))
const sunSlots = findFreeSlots(sun, day(6), earlyNow)
check(
  'Kein Lernblock endet nach 21:30',
  sunSlots.every((s) => !s.study || s.study.end <= atTime(day(6), 21, 30)),
)

// 8. Lücken unter 90 min sind kein Lernfenster
check(
  'Lernfenster sind mindestens 90 min lang',
  [...satSlots, ...sunSlots].every((s) => !s.study || (s.study.end.getTime() - s.study.start.getTime()) / 60000 >= 90),
)

// 9. Heute (20:17): freie Zeit beginnt frühestens jetzt
const mon = eventsForDay(events, day(0))
const monSlots = findFreeSlots(mon, day(0), now)
check('Heute: keine freie Zeit in der Vergangenheit', monSlots.every((s) => s.start >= now))

// 10. Frist-Hervorhebung: Abgabe Dienstag 23:59, jetzt Montag 20:17 -> unter 48 h
const due = events.find((e) => e.externalId === 'tu-due')!
check('Abgabe in 27 h: Hervorhebung 48 h', deadlineUrgency(due, now) === 'h48')
check('Abgabe in 2 h: Hervorhebung 3 h', deadlineUrgency(due, new Date(2026, 9, 13, 21, 59)) === 'h3')
check('Abgabe in 10 Tagen: keine Hervorhebung', deadlineUrgency(due, new Date(2026, 9, 3, 12, 0)) === null)
check('Abgabe in der Vergangenheit: keine Hervorhebung', deadlineUrgency(due, new Date(2026, 9, 14, 12, 0)) === null)
check('Normaler Termin wird nie hervorgehoben', deadlineUrgency(events[0], now) === null)

// 11. Nächster Termin
const next = nextEvent(events, now)
check('Nächster Termin ist die Abgabe oder früher am Dienstag', !!next && next.start > now, next?.title)

// 12. Termin ohne Ende erscheint nur an seinem Starttag
check('Termin ohne Ende nur am Starttag', eventsForDay(events, day(1)).timed.some((e) => e.id === due.id) &&
  !eventsForDay(events, day(2)).timed.some((e) => e.id === due.id))

// 13. Konsistenz Heute/Woche: jeder Termin erscheint an seinem Tag
let missing = 0
for (const e of events) {
  const d = new Date(e.start.getFullYear(), e.start.getMonth(), e.start.getDate())
  const dd = eventsForDay(events, d)
  if (![...dd.timed, ...dd.allDay].some((x) => x.id === e.id)) missing++
}
check('Jeder Termin erscheint an seinem Tag', missing === 0, `${missing} fehlen`)

// 14. Zeitwechsel Ende Oktober: 25.10.2026 hat 25 Stunden
const dstDay = new Date(2026, 9, 25)
const dstNext = addDays(dstDay, 1)
check('Sommerzeit-Ende: Tag hat 25 Stunden', (dstNext.getTime() - dstDay.getTime()) / 3600000 === 25 || process.env.TZ !== 'Europe/Zurich')

// 15. Duplikate und Quellenfehler
const dupSource: EventSource = {
  id: 'google',
  label: 'Google Kalender',
  isDemo: false,
  load: async () => [events[0], events[0], { ...events[0], title: 'Aktualisiert' }].map((e) => ({ ...e, id: 'google:x', source: 'google' as const })),
}
const failing: EventSource = { id: 'moodle', label: 'Moodle', isDemo: false, load: async () => { throw new Error('Verbindung abgelehnt') } }
const res = await loadAllSources([...SOURCES, dupSource, failing], now)
check('Duplikate (gleiche ID) werden zusammengeführt', res.events.filter((e) => e.id === 'google:x').length === 1)
check('Aktualisierung überschreibt alten Eintrag', res.events.find((e) => e.id === 'google:x')?.title === 'Aktualisiert')
check('Ausgefallene Quelle meldet Fehler', res.states.find((s) => s.id === 'moodle')?.status === 'error')
check('Andere Quellen funktionieren trotzdem', res.events.some((e) => e.source === 'test'))

// 16. Leere Daten
const emptyDay = eventsForDay([], day(0))
check('Leere Daten: kein Absturz', emptyDay.timed.length === 0 && findFreeSlots(emptyDay, day(0), earlyNow).length === 1)

console.log(failed === 0 ? '\nAlle Prüfungen bestanden.' : `\n${failed} Prüfung(en) fehlgeschlagen.`)
process.exit(failed === 0 ? 0 : 1)
